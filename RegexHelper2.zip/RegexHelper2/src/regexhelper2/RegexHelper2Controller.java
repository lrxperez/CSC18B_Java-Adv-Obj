// RegexHelper2Controller.java
package regexhelper2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import java.util.regex.*;
import javafx.fxml.Initializable;

public class RegexHelper2Controller implements Initializable {
    
    // GUI controls defined in FXML and used by the controller's code
    @FXML
    private TextField regexTextField;
    
    @FXML 
    private TextArea testDataTextArea;
    
    @FXML
    private TextField replaceTextField;
    
    @FXML
    private TextArea newDataTextArea;
    
    @FXML
    private void submitButtonAction(ActionEvent event) {
        
        try
        {
        String regex = regexTextField.getText();
        String data = testDataTextArea.getText();
        String replace = replaceTextField.getText();
        
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(data);
        
        data = m.replaceAll(replace);
        newDataTextArea.setText(data);
        }
        
        catch(PatternSyntaxException e)
        {
            regexTextField.setText("Enter a regular expression");
            regexTextField.selectAll();
            regexTextField.requestFocus();
        }
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
